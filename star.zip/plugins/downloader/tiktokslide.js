exports.run = {
usage: ['tiktokslide'],
hidden: ['ttslide'],
use: 'link tiktok',
category: 'downloader',
async: async (m, { func, mecha, errorMessage }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'https://www.tiktok.com/t/ZTNkBtxpp/'));
if (!m.args[0].includes('tiktok.com')) return m.reply(global.mess.error.url);
mecha.sendReact(m.chat, '💬', m.key);
try {
let res = await func.fetchJson(`https://skizo.tech/api/tiktok?apikey=syauqi27&url=${m.args[0]}`);
if (res.code !== 0) return m.reply(global.mess.error.api);
if (!res.data) return m.reply('Image not found.');
if (res.data.images.length === 0) return m.reply('Image not found.');
let data = res.data;
let txt = `*T I K T O K - S L I D E*\n`;
txt += `\n- Title: ${data.title ?? 'Not Known'}`;
txt += `\n- Total Images: ${data.images.length}`;
txt += `\n\n_Please wait, the images are being sent..._`;
await mecha.sendMessage(m.chat, { text: txt }, { quoted: m, ephemeralExpiration: m.expiration }).then(async () => {
await mecha.sendMessage(m.chat, {
audio: {
url: data.music
},
mimetype: 'audio/mpeg',
ptt: false
}, {quoted: m, ephemeralExpiration: m.expiration});
// Send each image separately
for (let url of data.images) {
await mecha.sendMessage(m.chat, {
image: {
url: url
}
}, {quoted: m, ephemeralExpiration: m.expiration});
}
});
} catch (e) {
m.reply(global.mess.error.api);
return errorMessage(e);
}
},
limit: 1
};