const axios = require('axios');

async function igdl (url) {
const base = "https://widipe.com/download/igdl?url=";
const { data } = await axios.get(base + url);
const hasil = await data.result[0];
return hasil
}

exports.run = {
usage: ['instagram'],
hidden: ['ig'],
use: 'enter the link', 
category: 'downloader',
async: async (m, { mecha }) => {
if (!m.args[0] || !m.args[0].startsWith('https://')) return m.reply('Mana linknya WOYY!')
mecha.sendReact(m.chat, '🕒', m.key)
let res = await igdl(m.args[0])
mecha.sendMedia(m.chat, res.url, m, { caption: global.mess.ok, expiration: m.expiration }).then(() => mecha.sendReact(m.chat, '✅', m.key))
}}