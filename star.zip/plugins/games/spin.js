const fetch = require('node-fetch');

exports.run = {
  usage: ['spin'],
  use: 'jumlah',
  category: 'games',
  async: async (m, { func, mecha, users, setting }) => {
    if (!('lastSpin' in users)) users.lastSpin = 0;
    if (!('streak' in users)) users.streak = 0; // Track win/loss streaks
    if (!m.text || !/^\d+$/.test(m.text)) return m.reply(func.example(m.cmd, '1000'));

    let betAmount = parseInt(m.text);
    if (users.balance < betAmount) return m.reply('Balance Anda tidak mencukupi.');

    // Adjusted outcomes with 20% win probability
    let outcomes = [
      { type: 'jackpot', chance: 0.02, multiplier: 15, emoji: '🎰', message: ["Incredible!", "Unbelievable! Jackpot!"] },   // 2% chance for 15x
      { type: 'bigWin', chance: 0.05, multiplier: 5, emoji: '🏆', message: ["Big Win!", "You're on fire!"] },                // 5% chance for 5x
      { type: 'moderateWin', chance: 0.05, multiplier: 2, emoji: '🥈', message: ["Nice win!", "Not bad at all!"] },          // 5% chance for 2x
      { type: 'smallWin', chance: 0.08, multiplier: 1.2, emoji: '😊', message: ["A small win!", "You got something!"] },     // 8% chance for 1.2x
      { type: 'breakEven', chance: 0.2, multiplier: 1, emoji: '😐', message: ["Broke even!", "No gain, no loss."] },         // 20% chance to break even
      { type: 'smallLoss', chance: 0.35, multiplier: -0.5, emoji: '😕', message: ["Small loss.", "Could be worse!"] },       // 35% chance to lose 50%
      { type: 'bigLoss', chance: 0.25, multiplier: -1, emoji: '😞', message: ["Big loss!", "Ouch, tough luck."] }            // 25% chance to lose 100%
    ];

    // Determine the outcome based on weighted probabilities
    let random = Math.random();
    let outcome = outcomes.find(o => (random -= o.chance) < 0);
    let wonAmount = Math.ceil(betAmount * outcome.multiplier);

    // Add delay and cooldown check
    let delay = 10000; // 10 seconds
    if (users.lastSpin && Number(new Date()) - users.lastSpin < delay) {
      let time = Math.ceil((users.lastSpin + delay - Number(new Date())) / 1000);
      return m.reply(`Harap tunggu ${time} detik sebelum menjalankan putaran berikutnya.`);
    }
    users.lastSpin = Number(new Date());

    // Update user balance
    users.balance += wonAmount;

    // Adjust the streak based on the outcome type
    if (wonAmount > 0) {
      users.streak = users.streak > 0 ? users.streak + 1 : 1;
    } else if (wonAmount < 0) {
      users.streak = users.streak < 0 ? users.streak - 1 : -1;
    }

    // Select a random message from outcome messages for variety
    let outcomeMessage = outcome.message[Math.floor(Math.random() * outcome.message.length)];

    // Custom message based on outcome with streak feedback
    let caption = `*🕹️ Spin Results*\n\n`;
    caption += `*- Bet: ${betAmount.toLocaleString()}*\n`;
    caption += `${outcome.emoji} *${outcomeMessage}*\n`;
    caption += outcome.multiplier > 0 ? `*+ ${wonAmount.toLocaleString()}*` : `*- ${Math.abs(wonAmount).toLocaleString()}*`;
    caption += `\n\n• Total Balance: *${users.balance.toLocaleString()}*`;

    // Add special message for winning/losing streaks
    if (users.streak >= 3) {
      caption += `\n🔥 *You're on a ${users.streak}-win streak! Keep it going!*`;
    } else if (users.streak <= -3) {
      caption += `\n💔 *You're on a ${Math.abs(users.streak)}-loss streak. Don't give up!*`;
    }

    // Send the message with enhanced feedback
    mecha.sendMessageModify(m.chat, caption, m, {
      title: global.header,
      body: 'S P I N - R E S U L T',
      thumbnail: await (await fetch(setting.cover)).buffer(),
      largeThumb: true,
      expiration: m.expiration
    });
  },
  limit: true
};