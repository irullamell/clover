const axios = require('axios');

exports.run = {
    usage: ['openai'],
    hidden: ['ai'],
    use: 'question',
    category: 'ai',
    async: async (m, { func, mecha }) => {
        // Memastikan bahwa ada teks yang masuk untuk diproses.
        if (!m.text) return m.reply(func.example(m.cmd, 'apakah kamu gpt4?'));

        // Mengirim reaksi untuk memberi tahu bahwa proses sedang berlangsung.
        mecha.sendReact(m.chat, '🕒', m.key);

        try {
            // Mengirim pesan loading
            await mecha.reply(m.chat, 'Loading...', m);
            
            // Mendapatkan jawaban dari LuminAI.
            const result = await luminAi(m.text, m.sender, 'Kamu adalah AI yang sangat berguna');
            
            // Mengirim balasan ke pengguna.
            mecha.reply(m.chat, result, m);
        } catch (error) {
            console.error('Terjadi kesalahan:', error);
            mecha.reply(m.chat, `Terjadi kesalahan: ${String(error)}`, m);
        }
    },
    limit: true
}

async function luminAi(teks, pengguna = null, prompt = null, modePencarianWeb = false) {
    try {
        const data = { content: teks };
        if (pengguna !== null) data.user = pengguna;
        if (prompt !== null) data.prompt = prompt;
        data.webSearchMode = modePencarianWeb;

        const { data: res } = await axios.post("https://luminai.my.id/", data);
        return res.result;
    } catch (error) {
        console.error('Terjadi kesalahan:', error);
        throw error;
    }
}