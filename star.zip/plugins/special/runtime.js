exports.run = {
  usage: ['runtime'],
  hidden: ['bot'],
  category: 'special',
  async: async (m, { func, mecha, setting, fkon }) => {
    // Mengambil waktu saat bot aktif
    const uptime = func.runtime(process.uptime());

    // Format pesan lebih interaktif dan mendetail
    const message = `Halo, ${m.pushname}! 👋\n\n` +
      `Bot telah aktif selama: ${uptime}\n` +
      `Terima kasih telah menggunakan layanan kami! 😊\n\n` +
      `Fitur yang tersedia:\n` +
      `- Penggunaan perintah cepat\n` +
      `- Balasan interaktif\n` +
      `- Statistik pemakaian\n\n` +
      `Kami berharap pengalaman Anda menyenangkan! 🚀`;

    // Menambahkan opsi lebih lanjut dalam pengaturan pesan
    await mecha.sendMessageModify(m.chat, message, fkon, {
      title: 'Status Aktivitas Bot',
      body: `Durasi Aktif: ${uptime}`,
      footer: 'Dapatkan informasi terbaru tentang bot di sini',
      buttonText: 'Selengkapnya',
      sections: [
        {
          title: 'Opsi Perintah',
          rows: [
            { title: 'Status Bot', rowId: 'runtime' },
            { title: 'Panduan Penggunaan', rowId: 'help' },
            { title: 'Kontak Admin', rowId: 'admin' }
          ]
        },
        {
          title: 'Lainnya',
          rows: [
            { title: 'Pengaturan Bot', rowId: 'settings' },
            { title: 'Informasi Server', rowId: 'serverInfo' }
          ]
        }
      ],
      thumbUrl: setting.cover,
      largeThumb: true,
      url: null,
      expiration: m.expiration || 300
    });
  }
};