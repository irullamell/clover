const fetch = require('node-fetch');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

async function upload (buffer) {
/**
 * Upload image to catbox.moe
 * Supported mimetype:
 * - `image/jpeg`
 * - `image/jpg`
 * - `image/png`
 * - `image/gif`
 * @param {Buffer} buffer Image Buffer
 */
try {
let { ext } = await fromBuffer(buffer);
let bodyForm = new FormData();
bodyForm.append("fileToUpload", buffer, "file." + ext);
bodyForm.append("reqtype", "fileupload");

let res = await fetch("https://catbox.moe/user/api.php", {
method: "POST",
body: bodyForm,
});

let url = await res.text();
return {
status: true,
url
}
} catch (error) {
return {
status: false,
message: String(error)
}
}
}

exports.run = {
usage: ['setcover'],
hidden: ['cover'],
use: 'reply photo',
category: 'owner',
async: async (m, { func, mecha, setting, quoted }) => {
if (!/image/.test(quoted.mime)) return m.reply('Image not found.')
let buffer = await quoted.download()
let data = await upload(buffer);
if (!data.status) return m.reply(data.message)
setting.cover = data.url
mecha.reply(m.chat, func.texted('bold', 'Cover successfully set.'), m)
},
owner: true
}